﻿

function includeFunction()
{
	UI_testTextEdit.append("includeFunction");
}
