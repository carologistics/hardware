#!/bin/sh

#Get the folder in witch this bash file resides (this is the ScriptCommunicator folder).
SCRIPTCOMMUNICATOR_DIR=$(dirname $0)

#Check if this bash file is startet by a link.
if(test -L $0)
then

  #Get the directory to with the link points to (this is the ScriptCommunicator folder).
  SCRIPTCOMMUNICATOR_DIR=`readlink $0`
  SCRIPTCOMMUNICATOR_DIR=$(dirname $SCRIPTCOMMUNICATOR_DIR)
fi

cd $SCRIPTCOMMUNICATOR_DIR

LD_LIBRARY_PATH=./lib
export LD_LIBRARY_PATH

chmod +x ./ScriptCommunicator
chmod +x ./designer
chmod +x ./ScriptEditor
chmod +x ./DeleteFolder

./ScriptCommunicator "$@"
