to execute ScriptCommunicator:
- make ScriptCommunicator.sh executable (chmod +x ./ScriptCommunicator.sh)
- run ScriptCommunicator.sh